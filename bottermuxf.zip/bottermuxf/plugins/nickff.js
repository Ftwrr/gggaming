let fetch = require('node-fetch')
let handler = async (m, { conn }) => {
  const res = await fetch('https://api.zeks.xyz/api/nickepep?apikey=apivinz')
const json = await res.json()
conn.reply(m.chat, `${json.result} ~yahahah hayyuk`, m)
}
handler.help = ['nickff']
handler.tags = ['fun']
handler.command = /^(nickff(dl)?)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler
