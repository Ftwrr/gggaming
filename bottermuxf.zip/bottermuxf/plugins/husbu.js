let fetch = require('node-fetch')

let handler = async(m, { conn, args, usedPrefix }) => {
        fetch('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/random/anime/husbu.txt')
            .then(res => res.text())
            .then(body => {
                let randomkpop = body.split('\n')
                let randomkpopx = randomkpop[Math.floor(Math.random() * randomkpop.length)]
                conn.sendFile(m.chat, randomkpopx, '', 'Hih Wibu', m)
            })
}
handler.help = ['husbu']
handler.tags = ['fun']
handler.command = /^(husbu)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.exp = 0
handler.limit = false

module.exports = handler