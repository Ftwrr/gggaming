let handler  = async (m, { conn }) => {
	this.sendContact(m.chat, '6282393157713', 'Fatur', m)
	conn.reply(m.chat, '+100 xp', m)
	global.DATABASE._data.users[m.sender].exp += 100
	}
handler.customPrefix = /wayaewayae/i
handler.command = new RegExp


module.exports = handler