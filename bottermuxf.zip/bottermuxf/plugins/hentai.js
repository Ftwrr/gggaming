let imageToBase64 = require('image-to-base64');
let axios = require("axios");
let handler = async(m, { conn, text }) => {
let str = `
TOBAT BODO
`.trim()

    axios.get('https://tobz-api.herokuapp.com/api/hentai?apikey=BotWeA')
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            let buf = Buffer.from(ress, 'base64')

     conn.sendFile(m.chat, buf, 'hentai.jpg', str, m)
        })
    })
}
handler.help = ['hentai']
handler.tags = ['fun']
handler.command = /^(hentai)$/i
handler.owner = true
handler.premium = true
handler.fail = null
handler.limit = true

module.exports = handler
