let imageToBase64 = require('image-to-base64');
let axios = require("axios");
let handler = async(m, { conn, text }) => {
let str = `
Why Are You Gay?
`.trim()

    axios.get('https://tobz-api.herokuapp.com/api/nsfwtrap?apikey=BotWeA')
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            let buf = Buffer.from(ress, 'base64')

     conn.sendFile(m.chat, buf, 'hentai.jpg', str, m)
        })
    })
}
handler.help = ['nsfwtrap']
handler.tags = ['fun']
handler.command = /^(nsfwtrap)$/i
handler.owner = true
handler.premium = true
handler.fail = null
handler.limit = true

module.exports = handler
