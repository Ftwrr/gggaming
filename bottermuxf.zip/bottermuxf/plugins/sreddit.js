let imageToBase64 = require('image-to-base64');
let axios = require("axios");
let handler = async(m, { conn, text }) => {
	if (!text) throw `Uhm apa`

    axios.get('https://meme-api.herokuapp.com/gimme/' + text + '/')
    .then((res) => {
      imageToBase64(res.data.url)
        .then(
          (ress) => {
            let buf = Buffer.from(ress, 'base64')

     conn.sendFile(m.chat, buf, 'memek.jpg', `${res.data.title}\n${res.data.postLink}`, m)
        })
    })
}
handler.help = ['sreddit']
handler.tags = ['internet']
handler.command = /^(sreddit)$/i

module.exports = handler
