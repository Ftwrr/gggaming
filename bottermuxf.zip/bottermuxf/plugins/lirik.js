let fetch = require('node-fetch')
let handler = async (m, { conn, args, text }) => {
  if (!args[0]) throw 'Uhm...apa?'
  const res = await fetch('http://scrap.terhambar.com/lirik?word=' + text )
const json = await res.json()
conn.reply(m.chat, json.result.lirik, m)
}
handler.help = ['lirik'].map(v => v + ' <lagu>')
handler.tags = ['internet']
handler.command = /^(lirik|lyrics)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler
