let fetch = require('node-fetch')
let handler = async (m, { conn }) => {
  const res = await fetch('https://api.zeks.xyz/api/fml')
const json = await res.json()
conn.reply(m.chat, json.result, m)
}
handler.help = ['fuck my life']
handler.tags = ['quotes']
handler.customPrefix = /fuck my life/i
handler.command = new RegExp
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler
