let imageToBase64 = require('image-to-base64');
let axios = require("axios");
let handler = async(m, { conn, text }) => {
let str = `
Wall
`.trim()

    axios.get('http://api-melodicxt-2.herokuapp.com/api/random/wallpaper?apiKey=administrator')
    .then((res) => {
      imageToBase64(res.data.result.result)
        .then(
          (ress) => {
            let buf = Buffer.from(ress, 'base64')

     conn.sendFile(m.chat, buf, 'wallpaper.jpg', str, m)
        })
    })
}
handler.help = ['wallpaper']
handler.tags = ['internet']
handler.command = /^(wallpaper|wall)$/i

module.exports = handler
