let handler = function (m) {
   this.sendContact(m.chat, '6282393157713', 'Fatur', m)
   conn.reply(m.chat, 'sv fatur', m)
}
handler.help = ['owner', 'creator']
handler.tags = ['info']

handler.customPrefix = /owner/i
handler.command = new RegExp

module.exports = handler
