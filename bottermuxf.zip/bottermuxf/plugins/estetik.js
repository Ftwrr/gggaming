let imageToBase64 = require('image-to-base64');
let axios = require("axios");
let handler = async(m, { conn, text }) => {
let str = `
estetik
`.trim()

    axios.get('https://api.zeks.xyz/api/estetikpic?apikey=apivinz')
    .then((res) => {
      imageToBase64(res.data.result.result)
        .then(
          (ress) => {
            let buf = Buffer.from(ress, 'base64')

     conn.sendFile(m.chat, buf, 'loli.jpg', str, m)
        })
    })
}
handler.help = ['estetik']
handler.tags = ['internet']
handler.command = /^(estetik)$/i


module.exports = handler
