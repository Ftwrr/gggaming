let handler  = async (m, { conn }) => {
	conn.reply(m.chat, '%readmore', m)
}
handler.customPrefix = /repmor/i
handler.command = new RegExp


module.exports = handler