let fetch = require('node-fetch')
let handler = async (m, { conn }) => {
  const res = await fetch('https://tobz-api.herokuapp.com/api/randomquotes?apikey=BotWeA')
const json = await res.json()
conn.reply(m.chat, `${json.quotes} ~${json.author}`, m)
}
handler.help = ['quotes']
handler.tags = ['quotes']
handler.command = /^(quotes(dl)?)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler
