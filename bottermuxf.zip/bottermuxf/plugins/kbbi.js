let fetch = require('node-fetch')
let handler = async (m, { conn, args, text }) => {
  if (!args[0]) throw 'Uhm...apa?'
  const res = await fetch('https://api.zeks.xyz/api/kbbi?q=' + text + '&apikey=apivinz')
const json = await res.json()
conn.reply(m.chat, json.result, m)
}
handler.help = ['kbbi'].map(v => v + ' <apa>')
handler.tags = ['internet']
handler.command = /^(kbbi)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler
