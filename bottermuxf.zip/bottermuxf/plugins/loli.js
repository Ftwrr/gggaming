let imageToBase64 = require('image-to-base64');
let axios = require("axios");
let handler = async(m, { conn, text }) => {
let str = `
Om jangan om
`.trim()

    axios.get('https://tobz-api.herokuapp.com/api/randomloli?apikey=BotWeA')
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            let buf = Buffer.from(ress, 'base64')

     conn.sendFile(m.chat, buf, 'loli.jpg', str, m)
        })
    })
}
handler.help = ['loli']
handler.tags = ['fun']
handler.command = /^(loli)$/i


module.exports = handler
